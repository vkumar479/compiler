Programming Language & Compilers by Vishal Kumar @01693580.
In this first assingment, a scanner.l file is being built using flex. It identifies keywords in the scanner.h file, operators, skips comments, white spaces,etc.
 To invoke the code  
set pp1 as working directory
type make hit enter
to give permissions chmod +x dcc
                    chmod +x dpp
to test against samples ./dcc <samples/badbool.frag for example.


