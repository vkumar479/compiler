/* File: ast_type.h
 * ----------------
 * In our parse tree, Type nodes are used to represent and
 * store type information. The base Type class is used
 * for built-in types, the NamedType for classes and interfaces,
 * and the ArrayType for arrays of other types.  
 *
 * pp3: You will need to extend the Type classes to implement
 * the type system and rules for type equivalency and compatibility.
 */
 
#ifndef _H_ast_type
#define _H_ast_type

#include "ast.h"
#include "list.h"
#include <iostream>
#include "hashtable.h"
#include <cstring>
#include "errors.h"
#include "ast_expr.h"

class Type : public Node 
{

  public :
    static Type *intType, *doubleType, *boolType, *voidType,
                *nullType, *stringType, *errorType;

    char *typeName;
    Type(yyltype loc) : Node(loc) {}
    Type(const char *str);
    
    virtual void PrintToStream(std::ostream& out) { out << typeName; }
    friend std::ostream& operator<<(std::ostream& out, Type *t) { t->PrintToStream(out); return out; }
    virtual bool IsEquivalentTo(Type *other) { return this == other; }
    virtual bool IsCompatibleWith(Hashtable<Node*> *table, Type *other);
    bool named;
};

class NamedType : public Type 
{
  public:
    Identifier *id;
    
    NamedType(Identifier *i);
    void PrintToStream(std::ostream& out) { out << id; }
    virtual bool IsEquivalentTo(Type *other) 
    {
       NamedType* nt = dynamic_cast<NamedType*>(other);
       if (!nt) return false; 
       return strcmp(id->name, nt->id->name) == 0; 
    }
    virtual bool IsCompatibleWith(Hashtable<Node*> *table, Type *other);
    virtual void Check(Hashtable<Node*> *table, int pass); 
};

class ArrayType : public Type 
{
  public:
    Type *elemType;

    ArrayType(yyltype loc, Type *elemType);
    
    void PrintToStream(std::ostream& out) { out << elemType << "[]"; }
    virtual void Check(Hashtable<Node*> *table, int pass);
    virtual bool IsEquivalentTo(Type *other) 
    {
       ArrayType* at = dynamic_cast<ArrayType*>(other);
       if (!at) { 
           return false; 
       }
       return elemType->IsEquivalentTo(at->elemType); 
    }
    virtual bool IsCompatibleWith(Hashtable<Node*> *table, Type *other);
};

 
#endif
