Compilers Project 2 (PP2) By Vishal Kumar Banner Id:@01693580 .
In this second assingment a parser is created using the yacc and the bison.
To run the code type make in the fox server
all the .o ,dcc file will be generated 
to check for the given samples
./dcc<samples/bad1.decaf>& bad1.outanderr