PP5 Final compiler project by Vishal Kumar Banner Id: 01693580.
To excute 
./dcc<samples/badnewarr.decaf>badnewarr.asm

cat defs.asm >> badnewarr.asm
 
To excute in spim
cd spim //change folder command
chmod +x spim //may need to change mod in spim 
./spim -file ../badnewarr.asm

