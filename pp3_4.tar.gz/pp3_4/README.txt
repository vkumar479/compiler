Compilers Project 3 (PP3_4) By Vishal Kumar Banner Id:@01693580 .
In this third assingment the semantic analyser is created for the compiler. It will transverse the AST and validate that the semantic rules are being respected fully.
To run the code use the make command to make all the .o ,dcc,.c files will be generated 
to check for the given samples
./dcc<samples/bad1.decaf>& bad1.outanderr